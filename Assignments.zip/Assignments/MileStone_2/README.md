Milestone 2 : Real-Time Sentiment & Intent Analysis Engine

Speech-to-Text 
Sentiment Analysis
Tone Analysis
Real-Time Intent Detection
Integrating4